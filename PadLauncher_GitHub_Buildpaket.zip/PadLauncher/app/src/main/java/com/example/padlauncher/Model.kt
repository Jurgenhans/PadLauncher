package com.example.padlauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import org.json.JSONArray
import org.json.JSONObject

/** Eine Zelle im Raster: Seite, Zeile, Spalte (alles 0-basiert). */
data class Cell(val page: Int, val row: Int, val col: Int)

data class AppInfo(
    val key: String,              // ComponentName als String, eindeutig pro Start-Activity
    val label: String,
    val component: ComponentName,
    val icon: ImageBitmap,
    val isSystem: Boolean
)

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map {
            val cn = ComponentName(it.activityInfo.packageName, it.activityInfo.name)
            AppInfo(
                key = cn.flattenToString(),
                label = it.loadLabel(pm).toString(),
                component = cn,
                icon = it.loadIcon(pm).toBitmap(160, 160).asImageBitmap(),
                isSystem = (it.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                    (it.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            )
        }
        .sortedBy { it.label.lowercase() }
}

/** Speichert Einstellungen und die Icon-Positionen dauerhaft. */
class Settings(ctx: Context) {
    private val sp = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    var cols: Int
        get() = sp.getInt("cols", 6)
        set(v) = sp.edit().putInt("cols", v).apply()
    var rows: Int
        get() = sp.getInt("rows", 5)
        set(v) = sp.edit().putInt("rows", v).apply()
    var iconDp: Int
        get() = sp.getInt("iconDp", 56)
        set(v) = sp.edit().putInt("iconDp", v).apply()
    var spacingDp: Int
        get() = sp.getInt("spacingDp", 4)
        set(v) = sp.edit().putInt("spacingDp", v).apply()
    var pages: Int
        get() = sp.getInt("pages", 2)
        set(v) = sp.edit().putInt("pages", v).apply()
    var showLabels: Boolean
        get() = sp.getBoolean("labels", true)
        set(v) = sp.edit().putBoolean("labels", v).apply()

    fun loadLayout(): Map<String, Cell> {
        val raw = sp.getString("layout", null) ?: return emptyMap()
        return try {
            val obj = JSONObject(raw)
            buildMap {
                obj.keys().forEach { k ->
                    val a: JSONArray = obj.getJSONArray(k)
                    put(k, Cell(a.getInt(0), a.getInt(1), a.getInt(2)))
                }
            }
        } catch (e: Exception) {
            emptyMap()
        }
    }

    fun saveLayout(layout: Map<String, Cell>) {
        val obj = JSONObject()
        layout.forEach { (k, c) -> obj.put(k, JSONArray(listOf(c.page, c.row, c.col))) }
        sp.edit().putString("layout", obj.toString()).apply()
    }
}

/**
 * Legt alle Apps auf Zellen. Gespeicherte Positionen werden behalten, solange sie noch
 * ins Raster passen. Alle anderen Apps kommen auf den ersten freien Platz.
 * Gibt die Positionen und die tatsächlich nötige Seitenzahl zurück.
 */
fun resolveLayout(
    keys: List<String>,
    stored: Map<String, Cell>,
    cols: Int,
    rows: Int,
    pages: Int
): Pair<Map<String, Cell>, Int> {
    val result = LinkedHashMap<String, Cell>()
    val used = HashSet<Cell>()
    for (k in keys) {
        val c = stored[k] ?: continue
        if (c.row < rows && c.col < cols && c.page < pages && used.add(c)) result[k] = c
    }
    var totalPages = pages
    for (k in keys) {
        if (k in result) continue
        var page = 0
        var placed = false
        while (!placed) {
            loop@ for (r in 0 until rows) {
                for (c in 0 until cols) {
                    val cell = Cell(page, r, c)
                    if (used.add(cell)) {
                        result[k] = cell
                        placed = true
                        break@loop
                    }
                }
            }
            if (!placed) page++
        }
        if (page + 1 > totalPages) totalPages = page + 1
    }
    return result to totalPages
}
