package com.example.padlauncher

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import java.util.UUID
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Edge-to-Edge: Hintergrundbild geht hinter Status- und Navigationsleiste
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        requestHighRefreshRate()
        // Ein Launcher soll mit "Zurück" nicht beendet werden.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { /* nichts tun */ }
        })
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                LauncherScreen()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        requestHighRefreshRate()
    }

    /** Fordert die höchste Bildwiederholrate (z.B. 120 Hz) bei gleicher Auflösung an. */
    @Suppress("DEPRECATION")
    private fun requestHighRefreshRate() {
        try {
            val disp = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) display else windowManager.defaultDisplay
            disp ?: return
            val cur = disp.mode
            val best = disp.supportedModes
                .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
                .maxByOrNull { it.refreshRate } ?: return
            val lp = window.attributes
            lp.preferredDisplayModeId = best.modeId
            lp.preferredRefreshRate = best.refreshRate
            window.attributes = lp
        } catch (_: Throwable) {
            // Gerät unterstützt es nicht: einfach ignorieren
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LauncherScreen() {
    val ctx = LocalContext.current
    val settings = remember { Settings(ctx) }
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current

    var cols by remember { mutableIntStateOf(settings.cols) }
    var rows by remember { mutableIntStateOf(settings.rows) }
    var iconDp by remember { mutableIntStateOf(settings.iconDp) }
    var spacingDp by remember { mutableIntStateOf(settings.spacingDp) }
    var pagesSetting by remember { mutableIntStateOf(settings.pages) }
    var showLabels by remember { mutableStateOf(settings.showLabels) }
    var stored by remember { mutableStateOf(settings.loadLayout()) }
    var folders by remember { mutableStateOf(settings.loadFolders()) }
    var menuFor by remember { mutableStateOf<String?>(null) }
    var openFolder by remember { mutableStateOf<String?>(null) }
    var renameFolder by remember { mutableStateOf<String?>(null) }
    var renameText by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }

    // Drag-Zustand
    var dragKey by remember { mutableStateOf<String?>(null) }
    var dragPos by remember { mutableStateOf(Offset.Zero) }
    var dragStart by remember { mutableStateOf(Offset.Zero) }
    var dragMoved by remember { mutableStateOf(false) }
    var gridSize by remember { mutableStateOf(IntSize.Zero) }

    fun saveFolders(list: List<Folder>) {
        folders = list
        settings.saveFolders(list)
    }

    // App-Liste neu laden, wenn der Launcher wieder sichtbar wird (z.B. nach Installation)
    var reload by remember { mutableIntStateOf(0) }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) reload++
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val apps by produceState(emptyList<AppInfo>(), reload) {
        value = withContext(Dispatchers.Default) { loadApps(ctx) }
    }
    val appsByKey = remember(apps) { apps.associateBy { it.key } }

    // Ordner nur mit installierten Apps anzeigen
    val validFolders = remember(folders, appsByKey) {
        if (appsByKey.isEmpty()) emptyList()
        else folders.map { f -> f.copy(apps = f.apps.filter { it in appsByKey }) }.filter { it.apps.isNotEmpty() }
    }
    val foldersById = remember(validFolders) { validFolders.associateBy { it.id } }
    val layoutKeys = remember(apps, validFolders) {
        val inFolder = validFolders.flatMap { it.apps }.toSet()
        validFolders.map { it.id } + apps.map { it.key }.filter { it !in inFolder }
    }

    val (resolved, pageCount) = remember(layoutKeys, stored, cols, rows, pagesSetting) {
        resolveLayout(layoutKeys, stored, cols, rows, pagesSetting)
    }
    val occupants = remember(resolved) { resolved.entries.associate { it.value to it.key } }

    val pagerState = rememberPagerState(pageCount = { pageCount })

    fun launchApp(app: AppInfo) {
        try {
            ctx.startActivity(
                Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(app.component)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            Toast.makeText(ctx, "App kann nicht gestartet werden", Toast.LENGTH_SHORT).show()
        }
    }

    fun cellAt(pos: Offset): Cell? {
        if (gridSize.width == 0 || gridSize.height == 0) return null
        if (pos.x < 0f || pos.y < 0f || pos.x >= gridSize.width || pos.y >= gridSize.height) return null
        val c = (pos.x / (gridSize.width.toFloat() / cols)).toInt().coerceIn(0, cols - 1)
        val r = (pos.y / (gridSize.height.toFloat() / rows)).toInt().coerceIn(0, rows - 1)
        return Cell(pagerState.currentPage, r, c)
    }

    val onTapAt: (Offset) -> Unit = { pos ->
        val key = cellAt(pos)?.let { occupants[it] }
        if (key != null) {
            if (key.startsWith(FOLDER_PREFIX)) openFolder = key
            else appsByKey[key]?.let { launchApp(it) }
        }
    }

    val onDragBegin: (Offset) -> Boolean = { pos ->
        val key = cellAt(pos)?.let { occupants[it] }
        if (key != null) {
            dragKey = key
            dragStart = pos
            dragPos = pos
            dragMoved = false
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            true
        } else false
    }

    val onDragMove: (Offset) -> Unit = { pos ->
        dragPos = pos
        if (!dragMoved && (pos - dragStart).getDistance() > 24f) dragMoved = true
    }

    val onDragFinish: (Offset) -> Unit = { pos ->
        val k = dragKey
        val moved = dragMoved
        dragKey = null
        dragMoved = false
        if (k != null) {
            if (!moved) {
                // Nur lange gedrückt, nicht gezogen: Menü zeigen
                menuFor = k
            } else {
                val target = cellAt(pos)
                val old = resolved[k]
                if (target != null && old != null && target != old) {
                    val other = occupants[target]
                    val updated = resolved.toMutableMap()
                    val draggingFolder = k.startsWith(FOLDER_PREFIX)
                    when {
                        other == null -> updated[k] = target
                        other == k -> {}
                        !draggingFolder && other.startsWith(FOLDER_PREFIX) -> {
                            saveFolders(folders.map { if (it.id == other) it.copy(apps = it.apps + k) else it })
                            updated.remove(k)
                        }
                        !draggingFolder -> {
                            val id = FOLDER_PREFIX + UUID.randomUUID().toString().take(8)
                            saveFolders(folders + Folder(id, "Ordner", listOf(other, k)))
                            updated.remove(k)
                            updated.remove(other)
                            updated[id] = target
                        }
                        else -> {
                            updated[k] = target
                            updated[other] = old
                        }
                    }
                    stored = updated
                    settings.saveLayout(updated)
                }
            }
        }
    }

    val tapState = rememberUpdatedState(onTapAt)
    val beginState = rememberUpdatedState(onDragBegin)
    val moveState = rememberUpdatedState(onDragMove)
    val finishState = rememberUpdatedState(onDragFinish)

    // Am Rand ziehen => Seite wechseln
    val edgePx = with(density) { 56.dp.toPx() }
    val edgeSide by remember {
        derivedStateOf {
            if (dragKey != null && dragMoved) {
                when {
                    dragPos.x < edgePx -> -1
                    dragPos.x > gridSize.width - edgePx -> 1
                    else -> 0
                }
            } else 0
        }
    }
    LaunchedEffect(edgeSide) {
        if (edgeSide != 0) {
            delay(500)
            while (true) {
                val t = (pagerState.currentPage + edgeSide).coerceIn(0, pagerState.pageCount - 1)
                if (t != pagerState.currentPage) pagerState.animateScrollToPage(t)
                delay(900)
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.25f))
            .systemBarsPadding()
    ) {
        Column(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .onSizeChanged { gridSize = it }
                    .pointerInput(Unit) {
                        val slop = viewConfiguration.touchSlop
                        val longPressMs = viewConfiguration.longPressTimeoutMillis
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                            val start = down.position
                            // 1 = Tippen, 2 = gewischt / abgebrochen, null = lange gedrückt
                            val phase = withTimeoutOrNull(longPressMs) {
                                var r = 0
                                while (r == 0) {
                                    val ev = awaitPointerEvent(PointerEventPass.Initial)
                                    val ch = ev.changes.firstOrNull { it.id == down.id }
                                    r = when {
                                        ch == null -> 2
                                        !ch.pressed -> 1
                                        (ch.position - start).getDistance() > slop -> 2
                                        else -> 0
                                    }
                                }
                                r
                            }
                            if (phase == 1) {
                                tapState.value(start)
                            } else if (phase == null) {
                                if (beginState.value(start)) {
                                    while (true) {
                                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                                        val ch = ev.changes.firstOrNull { it.id == down.id }
                                        if (ch == null) {
                                            finishState.value(start)
                                            break
                                        }
                                        ch.consume()
                                        if (!ch.pressed) {
                                            finishState.value(ch.position)
                                            break
                                        }
                                        moveState.value(ch.position)
                                    }
                                }
                            }
                        }
                    }
            ) {
                HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { page ->
                    Column(Modifier.fillMaxSize()) {
                        repeat(rows) { r ->
                            Row(Modifier.weight(1f).fillMaxWidth()) {
                                repeat(cols) { c ->
                                    val key = occupants[Cell(page, r, c)]
                                    val app = key?.let { appsByKey[it] }
                                    val folder = key?.let { foldersById[it] }
                                    Box(
                                        Modifier
                                            .weight(1f)
                                            .fillMaxHeight()
                                            .padding(spacingDp.dp)
                                            .alpha(if (key != null && key == dragKey && dragMoved) 0.25f else 1f),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (app != null) AppTile(app, iconDp, showLabels)
                                        else if (folder != null) FolderTile(folder, appsByKey, iconDp, showLabels)
                                    }
                                }
                            }
                        }
                    }
                }

                // Gezogenes Element folgt dem Finger
                val dk = dragKey
                if (dk != null && dragMoved) {
                    val dApp = appsByKey[dk]
                    val dFolder = foldersById[dk]
                    val half = with(density) { (iconDp.dp / 2).toPx() }
                    Box(
                        Modifier
                            .offset { IntOffset((dragPos.x - half).roundToInt(), (dragPos.y - half).roundToInt()) }
                            .alpha(0.9f)
                    ) {
                        if (dApp != null) AppTile(dApp, iconDp, false)
                        else if (dFolder != null) FolderTile(dFolder, appsByKey, iconDp, false)
                    }
                }
            }

            // Seitenpunkte
            Box(Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
                Row(
                    Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    repeat(pageCount) { i ->
                        Box(
                            Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(
                                    if (pagerState.currentPage == i) Color.White else Color.White.copy(alpha = 0.35f)
                                )
                        )
                    }
                }
            }
        }
    }

    // Ordner öffnen
    val openF = openFolder?.let { foldersById[it] }
    if (openF != null) {
        AlertDialog(
            onDismissRequest = { openFolder = null },
            confirmButton = { TextButton(onClick = { openFolder = null }) { Text("Schließen") } },
            title = { Text(openF.name) },
            text = {
                Column {
                    openF.apps.mapNotNull { appsByKey[it] }.chunked(4).forEach { rowApps ->
                        Row(Modifier.fillMaxWidth()) {
                            rowApps.forEach { a ->
                                Box(
                                    Modifier
                                        .weight(1f)
                                        .combinedClickable(
                                            onClick = { openFolder = null; launchApp(a) },
                                            onLongClick = { menuFor = a.key }
                                        )
                                        .padding(4.dp),
                                    contentAlignment = Alignment.Center
                                ) { AppTile(a, 48, true) }
                            }
                            repeat(4 - rowApps.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                    Text(
                        "Tipp: App lange drücken für mehr Optionen.",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        )
    }

    // Ordner umbenennen
    val renF = renameFolder?.let { foldersById[it] }
    if (renF != null) {
        AlertDialog(
            onDismissRequest = { renameFolder = null },
            title = { Text("Ordner umbenennen") },
            text = { OutlinedTextField(value = renameText, onValueChange = { renameText = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    val n = renameText.trim().ifEmpty { "Ordner" }
                    saveFolders(folders.map { if (it.id == renF.id) it.copy(name = n) else it })
                    renameFolder = null
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { renameFolder = null }) { Text("Abbrechen") } }
        )
    }

    // Long-Press-Menü (als Dialog, damit es zuverlässig erscheint)
    val menuFolder = menuFor?.let { foldersById[it] }
    if (menuFolder != null) {
        AlertDialog(
            onDismissRequest = { menuFor = null },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { menuFor = null }) { Text("Abbrechen") } },
            title = { Text(menuFolder.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = {
                Column {
                    TextButton(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { menuFor = null; renameText = menuFolder.name; renameFolder = menuFolder.id }
                    ) { Text("Umbenennen", modifier = Modifier.fillMaxWidth()) }
                    TextButton(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            menuFor = null
                            saveFolders(folders.filter { it.id != menuFolder.id })
                        }
                    ) { Text("Ordner auflösen", modifier = Modifier.fillMaxWidth()) }
                    TextButton(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { menuFor = null; showSettings = true }
                    ) { Text("Launcher-Einstellungen", modifier = Modifier.fillMaxWidth()) }
                }
            }
        )
    }

    val menuApp = menuFor?.let { appsByKey[it] }
    if (menuApp != null) {
        val pkg = menuApp.component.packageName
        val inFolder = folders.any { menuApp.key in it.apps }
        fun launchSafely(intent: Intent, errorText: String) {
            try {
                ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                Toast.makeText(ctx, errorText, Toast.LENGTH_LONG).show()
            }
        }
        AlertDialog(
            onDismissRequest = { menuFor = null },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { menuFor = null }) { Text("Abbrechen") } },
            title = { Text(menuApp.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = {
                Column {
                    TextButton(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            menuFor = null
                            launchSafely(
                                Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")),
                                "Deinstallieren nicht möglich"
                            )
                        }
                    ) { Text("Deinstallieren", modifier = Modifier.fillMaxWidth()) }
                    TextButton(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            menuFor = null
                            launchSafely(
                                Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")),
                                "App-Info nicht verfügbar"
                            )
                        }
                    ) { Text("App-Info", modifier = Modifier.fillMaxWidth()) }
                    if (inFolder) {
                        TextButton(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                menuFor = null
                                saveFolders(
                                    folders
                                        .map { f -> if (menuApp.key in f.apps) f.copy(apps = f.apps - menuApp.key) else f }
                                        .filter { it.apps.isNotEmpty() }
                                )
                            }
                        ) { Text("Aus Ordner entfernen", modifier = Modifier.fillMaxWidth()) }
                    }
                    TextButton(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { menuFor = null; showSettings = true }
                    ) { Text("Launcher-Einstellungen", modifier = Modifier.fillMaxWidth()) }
                }
            }
        )
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Fertig") } },
            dismissButton = {
                TextButton(onClick = {
                    stored = emptyMap()
                    settings.saveLayout(emptyMap())
                }) { Text("Positionen zurücksetzen") }
            },
            title = { Text("Oberfläche anpassen") },
            text = {
                Column {
                    SliderRow("Spalten pro Seite", cols, 3..12) { cols = it; settings.cols = it }
                    SliderRow("Zeilen pro Seite", rows, 3..10) { rows = it; settings.rows = it }
                    Text(
                        "Apps pro Seite: ${cols * rows}",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                    SliderRow("Icon-Größe (dp)", iconDp, 32..112) { iconDp = it; settings.iconDp = it }
                    SliderRow("Abstand (dp)", spacingDp, 0..32) { spacingDp = it; settings.spacingDp = it }
                    SliderRow("Seiten (mindestens)", pagesSetting, 1..10) { pagesSetting = it; settings.pages = it }
                    Row(
                        Modifier.fillMaxWidth().padding(top = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("App-Namen anzeigen")
                        Switch(checked = showLabels, onCheckedChange = { showLabels = it; settings.showLabels = it })
                    }
                    Text(
                        "Tipp: App lange drücken und ziehen zum Verschieben (auch auf andere Seiten). " +
                            "Auf eine andere App ziehen erstellt einen Ordner. " +
                            "Lange drücken ohne Ziehen zeigt das Menü.",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.padding(top = 12.dp)
                    )
                }
            }
        )
    }
}

@Composable
private fun AppTile(app: AppInfo, iconDp: Int, showLabel: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Image(
            bitmap = app.icon,
            contentDescription = app.label,
            modifier = Modifier.size(iconDp.dp)
        )
        if (showLabel) {
            Text(
                app.label,
                color = Color.White,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

@Composable
private fun FolderTile(folder: Folder, appsByKey: Map<String, AppInfo>, iconDp: Int, showLabel: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(iconDp.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0x55FFFFFF))
                .padding(4.dp)
        ) {
            val preview = folder.apps.take(4).mapNotNull { appsByKey[it] }
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
                preview.chunked(2).forEach { rowApps ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        rowApps.forEach { a ->
                            Image(
                                bitmap = a.icon,
                                contentDescription = null,
                                modifier = Modifier.size((iconDp / 2 - 6).dp)
                            )
                        }
                    }
                }
            }
        }
        if (showLabel) {
            Text(
                folder.name,
                color = Color.White,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

@Composable
private fun SliderRow(label: String, value: Int, range: IntRange, onChange: (Int) -> Unit) {
    Column(Modifier.padding(top = 8.dp)) {
        Text("$label: $value", fontSize = 14.sp)
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.toInt()) },
            valueRange = range.first.toFloat()..range.last.toFloat(),
            steps = range.last - range.first - 1
        )
    }
}
