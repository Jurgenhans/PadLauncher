package com.example.padlauncher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Ein Launcher soll mit "Zurück" nicht beendet werden.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { /* nichts tun */ }
        })
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                LauncherScreen()
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LauncherScreen() {
    val ctx = LocalContext.current
    val settings = remember { Settings(ctx) }

    var cols by remember { mutableIntStateOf(settings.cols) }
    var rows by remember { mutableIntStateOf(settings.rows) }
    var iconDp by remember { mutableIntStateOf(settings.iconDp) }
    var spacingDp by remember { mutableIntStateOf(settings.spacingDp) }
    var pagesSetting by remember { mutableIntStateOf(settings.pages) }
    var showLabels by remember { mutableStateOf(settings.showLabels) }
    var stored by remember { mutableStateOf(settings.loadLayout()) }
    var selected by remember { mutableStateOf<String?>(null) }
    var showSettings by remember { mutableStateOf(false) }

    // App-Liste neu laden, wenn der Launcher wieder sichtbar wird (z.B. nach Installation)
    var reload by remember { mutableIntStateOf(0) }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) reload++
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val apps by produceState(emptyList<AppInfo>(), reload) {
        value = withContext(Dispatchers.Default) { loadApps(ctx) }
    }
    val appsByKey = remember(apps) { apps.associateBy { it.key } }

    val (resolved, pageCount) = remember(apps, stored, cols, rows, pagesSetting) {
        resolveLayout(apps.map { it.key }, stored, cols, rows, pagesSetting)
    }
    val occupants = remember(resolved) { resolved.entries.associate { it.value to it.key } }

    fun moveTo(target: Cell) {
        val sel = selected ?: return
        val old = resolved[sel] ?: return
        val other = occupants[target]
        val updated = resolved.toMutableMap()
        updated[sel] = target
        if (other != null && other != sel) updated[other] = old
        stored = updated
        settings.saveLayout(updated)
        selected = null
    }

    val pagerState = rememberPagerState(pageCount = { pageCount })

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.25f))
            .systemBarsPadding()
    ) {
        Column(Modifier.fillMaxSize()) {
            if (selected != null) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xCC1E1E1E))
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Tippe auf den neuen Platz (auch auf anderer Seite)", color = Color.White, fontSize = 14.sp)
                    TextButton(onClick = { selected = null }) { Text("Abbrechen") }
                }
            }

            HorizontalPager(state = pagerState, modifier = Modifier.weight(1f)) { page ->
                Column(Modifier.fillMaxSize()) {
                    repeat(rows) { r ->
                        Row(Modifier.weight(1f).fillMaxWidth()) {
                            repeat(cols) { c ->
                                val cell = Cell(page, r, c)
                                val key = occupants[cell]
                                val app = key?.let { appsByKey[it] }
                                Box(
                                    Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .padding(spacingDp.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(
                                            when {
                                                key != null && key == selected -> Color(0x667C4DFF)
                                                app == null && selected != null -> Color(0x22FFFFFF)
                                                else -> Color.Transparent
                                            }
                                        )
                                        .combinedClickable(
                                            onClick = {
                                                if (selected != null) {
                                                    if (selected == key) selected = null else moveTo(cell)
                                                } else if (app != null) {
                                                    ctx.startActivity(
                                                        Intent(Intent.ACTION_MAIN)
                                                            .addCategory(Intent.CATEGORY_LAUNCHER)
                                                            .setComponent(app.component)
                                                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                                    )
                                                }
                                            },
                                            onLongClick = { if (app != null) selected = app.key }
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (app != null) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Image(
                                                bitmap = app.icon,
                                                contentDescription = app.label,
                                                modifier = Modifier.size(iconDp.dp)
                                            )
                                            if (showLabels) {
                                                Text(
                                                    app.label,
                                                    color = Color.White,
                                                    fontSize = 12.sp,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    modifier = Modifier.padding(top = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Seitenpunkte + Einstellungen
            Box(Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
                Row(
                    Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    repeat(pageCount) { i ->
                        Box(
                            Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(
                                    if (pagerState.currentPage == i) Color.White else Color.White.copy(alpha = 0.35f)
                                )
                        )
                    }
                }
                TextButton(
                    onClick = { showSettings = true },
                    modifier = Modifier.align(Alignment.CenterEnd)
                ) { Text("⚙ Einstellungen") }
            }
        }
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Fertig") } },
            dismissButton = {
                TextButton(onClick = {
                    stored = emptyMap()
                    settings.saveLayout(emptyMap())
                    selected = null
                }) { Text("Positionen zurücksetzen") }
            },
            title = { Text("Oberfläche anpassen") },
            text = {
                Column {
                    SliderRow("Spalten pro Seite", cols, 3..12) { cols = it; settings.cols = it }
                    SliderRow("Zeilen pro Seite", rows, 3..10) { rows = it; settings.rows = it }
                    Text(
                        "Apps pro Seite: ${cols * rows}",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                    SliderRow("Icon-Größe (dp)", iconDp, 32..112) { iconDp = it; settings.iconDp = it }
                    SliderRow("Abstand (dp)", spacingDp, 0..32) { spacingDp = it; settings.spacingDp = it }
                    SliderRow("Seiten (mindestens)", pagesSetting, 1..10) { pagesSetting = it; settings.pages = it }
                    Row(
                        Modifier.fillMaxWidth().padding(top = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("App-Namen anzeigen")
                        Switch(checked = showLabels, onCheckedChange = { showLabels = it; settings.showLabels = it })
                    }
                    Text(
                        "Tipp: Icon lange drücken, dann auf den Zielplatz tippen, um es zu verschieben.",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.padding(top = 12.dp)
                    )
                }
            }
        )
    }
}

@Composable
private fun SliderRow(label: String, value: Int, range: IntRange, onChange: (Int) -> Unit) {
    Column(Modifier.padding(top = 8.dp)) {
        Text("$label: $value", fontSize = 14.sp)
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.toInt()) },
            valueRange = range.first.toFloat()..range.last.toFloat(),
            steps = range.last - range.first - 1
        )
    }
}
