# Pad Launcher

Eigener Homescreen (Launcher) für das Xiaomi Pad 7 mit einstellbarem Raster.

## Funktionen
- Spalten und Zeilen pro Seite einstellen (3–12 / 3–10)
- Icon-Größe und Abstände einstellen
- Mehrere Seiten zum Wischen (wachsen automatisch, wenn die Apps nicht passen)
- App-Namen ein-/ausblenden
- Icons verschieben: Icon lange drücken, dann auf den Zielplatz tippen (Tausch bei besetztem Platz)
- Positionen werden gespeichert, "Positionen zurücksetzen" in den Einstellungen

## Bauen
1. Android Studio (Koala oder neuer) installieren und den Ordner `PadLauncher` öffnen.
2. Gradle-Sync abwarten.
3. Pad per USB anschließen (Entwickleroptionen + USB-Debugging an) und auf "Run" klicken.
   Oder: Build > Build APK(s) und die APK auf dem Pad installieren.
4. Auf dem Pad: Einstellungen > Apps > Standard-Apps > Start-App > "Pad Launcher".
   Zurück zum Xiaomi-Launcher: dieselbe Einstellung wieder ändern.

## Hinweis
Der Code wurde nicht in Android Studio kompiliert oder auf einem Gerät getestet.
Falls Gradle Versionen bemängelt, in `build.gradle.kts` AGP/Kotlin-Version an die
Android-Studio-Vorschläge anpassen.
